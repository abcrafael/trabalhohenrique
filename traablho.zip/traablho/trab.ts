class SistemaDeGerenciamento {
    private static instance: SistemaDeGerenciamento;

    private constructor() {
    }

    public static getInstance(): SistemaDeGerenciamento {
        if (!SistemaDeGerenciamento.instance) {
            SistemaDeGerenciamento.instance = new SistemaDeGerenciamento();
        }
        return SistemaDeGerenciamento.instance;
    }
}

const sistema = SistemaDeGerenciamento.getInstance();

abstract class Usuario {
    constructor(public nome: string) {}
}

class Aluno extends Usuario {
}

class Funcionario extends Usuario {
}

abstract class UsuarioFactory {
    public abstract criarUsuario(nome: string): Usuario;
}

class AlunoFactory extends UsuarioFactory {
    public criarUsuario(nome: string): Usuario {
        return new Aluno(nome);
    }
}

class FuncionarioFactory extends UsuarioFactory {
    public criarUsuario(nome: string): Usuario {
        return new Funcionario(nome);
    }
}

const alunoFactory = new AlunoFactory();
const aluno = alunoFactory.criarUsuario("João");

interface SistemaDePagamento {
    processarPagamento(valor: number): void;
}

class PagamentoExterno {
    public realizarPagamento(quantia: number): void {
        console.log(`Pagamento ${quantia}`);
    }
}

class PagamentoAdapter implements SistemaDePagamento {
    private pagamentoExterno: PagamentoExterno;

    constructor(pagamentoExterno: PagamentoExterno) {
        this.pagamentoExterno = pagamentoExterno;
    }

    public processarPagamento(valor: number): void {
        this.pagamentoExterno.realizarPagamento(valor);
    }
}

const pagamentoExterno = new PagamentoExterno();
const pagamentoAdapter = new PagamentoAdapter(pagamentoExterno);
pagamentoAdapter.processarPagamento(100);

abstract class MembroUniversidade {
    constructor(protected nome: string) {}
    public abstract exibirDetalhes(): void;
}

class Professor extends MembroUniversidade {
    public exibirDetalhes(): void {
        console.log(`Professor: ${this.nome}`);
    }
}

class Departamento extends MembroUniversidade {
    private membros: MembroUniversidade[] = [];

    public adicionarMembro(membro: MembroUniversidade): void {
        this.membros.push(membro);
    }

    public removerMembro(membro: MembroUniversidade): void {
        const index = this.membros.indexOf(membro);
        if (index > -1) {
            this.membros.splice(index, 1);
        }
    }

    public exibirDetalhes(): void {
        console.log(`Departamento: ${this.nome}`);
        for (const membro of this.membros) {
            membro.exibirDetalhes();
        }
    }
}

const professor1 = new Professor("Henrique");
const professor2 = new Professor("Joseph");
const departamento = new Departamento("Computação");
departamento.adicionarMembro(professor1);
departamento.adicionarMembro(professor2);
departamento.exibirDetalhes();
